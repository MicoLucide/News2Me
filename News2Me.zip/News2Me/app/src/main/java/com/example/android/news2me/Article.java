package com.example.android.news2me;

public class Article {

    private String mTitle;
    private long mTimeInMilliseconds;
    private String mUrl;

    public Article(String title, long timeInMilliseconds, String url) {
        mTitle = title;
        mTimeInMilliseconds = timeInMilliseconds;
        mUrl = url;
    }

    public String getTitle() {
        return mTitle;
    }
    public long getTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }
    public String getUrl() {
        return mUrl;
    }
}
