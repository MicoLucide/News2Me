package com.example.android.news2me;

public class Article {

    private String mTitle;
    private String mSection;
    private String mContributor;
    private String mTimeInMilliseconds;
    private String mUrl;

    public Article(String title, String section, String contributor, String timeInMilliseconds, String url) {
        mTitle = title;
        mSection = section;
        mContributor = contributor;
        mTimeInMilliseconds = timeInMilliseconds;
        mUrl = url;
    }

    public String getTitle() {
        return mTitle;
    }
    public String getSection() {
        return mSection;
    }
    public String getContributor() {
        return mContributor;
    }
    public String getDate() {
        return mTimeInMilliseconds;
    }
    public String getUrl() {
        return mUrl;
    }
}
